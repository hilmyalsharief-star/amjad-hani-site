Sample CAD placeholder.
Replace with real DWG/DXF files from the admin panel.
